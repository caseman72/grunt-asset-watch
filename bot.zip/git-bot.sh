#!/bin/bash -e
#
# Purpose: find last commit and commit messages

# http://stackoverflow.com/questions/59895/can-a-bash-script-tell-what-directory-its-stored-in
#
bash_source="${BASH_SOURCE[0]}"
# resolve $bash_source until the file is no longer a symlink
while [ -h "${bash_source}" ]; do
  cwd="$(cd -P "$(dirname "${bash_source}")" && pwd)"
  bash_source="$(readlink "${bash_source}")"
  # if $bash_source was a relative symlink, we need to resolve it relative to the path where the symlink file was located
  [[ $bash_source != /* ]] && bash_source="${cwd}/${bash_source}"
done
cwd="$(cd -P "$(dirname "${bash_source}" )" && pwd )"

# args
if [[ $# -ne 2 ]]; then
	echo "Usage: git-bot <repo path> <branch>"
	exit 1
elif [[ ! -d $1 ]]; then
	echo "Usage: git-bot <repo path> <branch>"
	exit 1
elif [[ ! -d "$1/.git" ]]; then
	echo "Usage: git-bot <repo path> <branch>"
	exit 1
fi

# repo
skip=0
repo_path=$1
repo=$(basename "${repo_path}")
branch=$2

# hall connection
hall_room=$HALL_ROOM
hall_user=$HALL_USER
hall_pass=$HALL_PASS

# must be set in env
if [[ ${#hall_room} -eq 0 || ${#hall_user} -eq 0 || ${#hall_pass} -eq 0 ]];  then
	echo "Usage: HALL_ROOM='<room_id>' HALL_USER='<hall_user>' HALL_PASS='<hall_pass>' git-bot <repo path> <branch>"
	exit 1
fi

# move to repo directory
cd $repo_path

# sha1 file
sha1_file="${cwd}/sha1_${repo}_${branch}.txt"
if [[ ! -e "${sha1_file}" ]]; then
	git log $branch -n 1 --skip=$skip | head -n 1 | cut -d' ' -f2 | tr -d '\n' > "${sha1_file}"
	exit 0
fi

# sha1 of the last run
sha1=$(head -n 1 "${sha1_file}")

# update to lastest code base - no messages
git checkout -q $branch >& /dev/null && git reset --hard origin/$branch >& /dev/null && rm -f .git/index.lock && git pull -n -q >& /dev/null
# git fetch --all >& /dev/null

# new sha1 - keep for sha1_file
head="$(git log $branch -n 1 --skip=$skip | head -n 1 | cut -d' ' -f2)"

# loop until we find current sha1
curr=$head
while [[ "${curr}" != "${sha1}" && $skip -lt 20 ]]; do
	# commit messages
	log="$(git log $branch -n 1 --skip=$skip)"
	if [[ $log =~ Author:.*krkjenkins\.sky\.dom ]]; then
		log=""
	elif [[ $log =~ Updates\ generated.*\.CI\.2 ]]; then
		log=""
	elif [[ $log =~ minify\ post\-receive\ hook ]]; then
		log=""
	elif [[ $log =~ Merge\ remote\-tracking\ branch ]]; then
		log=""
	elif [[ $log =~ Merge\ branch ]]; then
		log=""
	elif [[ $log =~ copy_silverlight_editor ]]; then
		log=""
	fi
	line[skip]=$log

	skip="$(($skip+1))"
	curr="$(git log $branch -n 1 --skip=$skip | head -n 1 | cut -d' ' -f2)"
done

if [[ $skip -eq 0 ]]; then
	# nothing to do - exit
	exit 0

elif [[ $skip -ge 20 ]]; then
	# >= 20 - send message and start over
	#
	# TODO: send message
	#
	git log $branch -n 1 --skip=$skip | head -n 1 | cut -d' ' -f2 | tr -d '\n' > "${sha1_file}"
	exit 0
else
	# update sha1_file to current sha1
	echo -n "${head}" > "${sha1_file}"

	# msg file
	msg_file="${cwd}/posts/msg_${repo}_${branch}_${curr}.txt"
	run_flag=0

	# reset and load messages into msg_file
	echo -n "<pre>" > "${msg_file}"
	for (( idx=${#line[@]}-1; idx>=0; idx-- )); do
		commit="${line[idx]}"
		if [[ ${#commit} -gt 0 ]]; then
			link=$(echo "${commit}" | grep '^commit' | sed "s#^commit \(.\{7\}\).*#<a href='http://git.sky.dom/?p=${repo};a=commitdiff;h=\1'>http://git.sky.dom/?p=${repo};a=commitdiff;h=\1</a>#")
			echo "Diff:   $link "                             >> "${msg_file}"
			echo "Repo:   ${repo} [branch "'"'"${branch}"'"]' >> "${msg_file}"
			echo "${commit}" | grep -v "^commit"              >> "${msg_file}"
			echo                                              >> "${msg_file}"
			run_flag=1
		fi
	done

	# only if commits
	if [[ $run_flag -eq 1 ]]; then
		echo "</pre>" >> "${msg_file}"
		# /usr/local/bin/n use 0.10.25 "${cwd}/post-to-hall.js" "${hall_room}" "${msg_file}" "${hall_user}" "${hall_pass}" >> "${cwd}/run.log"
		/usr/local/bin/n use 0.10.28 "${cwd}/hipchat-project-tardis.js" "${msg_file}" >> "${cwd}/run.log"
	fi
fi
