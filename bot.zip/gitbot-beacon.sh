#!/bin/bash -e
#
git_bot=/usr/local/projects/cronjobs/gitbot-beacon/git-bot.sh
git_repo_vision=/usr/local/projects/cronjobs/repos/vision
git_repo_phpweblib=/usr/local/projects/cronjobs/repos/phpweblib
git_repo_centerpoint=/usr/local/projects/cronjobs/repos/centerpoint

test -x $git_bot && \
(HALL_ROOM='53a30cb681b5929126000282' HALL_USER='beacon.git@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_vision TARDIS-feb) && \
(HALL_ROOM='53a30cb681b5929126000282' HALL_USER='beacon.git@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_phpweblib TARDIS-feb)

#(HALL_ROOM='53a30cb681b5929126000282' HALL_USER='beacon.git@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_vision VIS-14232-non-canvas)
# (HALL_ROOM='52f991d69f1fb2fc0c00021b' HALL_USER='gitbot.retail@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_vision bugoff2014retail) && \
# (HALL_ROOM='52f991d69f1fb2fc0c00021b' HALL_USER='gitbot.retail@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_phpweblib bugoff2014retail) && \
# (HALL_ROOM='52f991d69f1fb2fc0c00021b' HALL_USER='gitbot.retail@gmail.com' HALL_PASS='Pinpoint123' $git_bot $git_repo_centerpoint bugoff2014retail)

